package com.example.zvonilka

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        val contacts = listOf(
            Contact("Иван Иванов", "+7 900 123-45-67", "ivan@mail.ru"),
            Contact("Мария Петрова", "+7 900 765-43-21", "maria@mail.ru"),
            Contact("Петр Сидоров", "+7 900 111-22-33", "petr@mail.ru"),
            Contact("Анна Козлова", "+7 900 444-55-66", "anna@mail.ru"),
            Contact("Сергей Николаев", "+7 900 777-88-99", "sergey@mail.ru"),
            Contact("Ольга Васнецова", "+7 900 000-11-22", "olga@mail.ru"),
            Contact("Дмитрий Орлов", "+7 900 333-44-55", "dmitry@mail.ru")
        )

        val recyclerView: RecyclerView = findViewById(R.id.recyclerViewContacts)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = ContactsAdapter(contacts)

        recyclerView.addItemDecoration(
            androidx.recyclerview.widget.DividerItemDecoration(
                this,
                androidx.recyclerview.widget.LinearLayoutManager.VERTICAL
            )
        )
    }
}