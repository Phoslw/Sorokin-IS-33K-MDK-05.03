package com.example.lox

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.graphics.BitmapFactory
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var editTextName: EditText
    private lateinit var buttonSearch: Button
    private lateinit var imageViewCharacter: ImageView
    private lateinit var textViewInfo: TextView

    @SuppressLint("CutPasteId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextName = findViewById(R.id.nameEditText)
        buttonSearch = findViewById(R.id.searchButton)
        imageViewCharacter = findViewById(R.id.imageView)
        textViewInfo = findViewById(R.id.textViewInfo)

        buttonSearch.setOnClickListener {
            val name = editTextName.text.toString().trim()
            if (name.isNotEmpty()) {
                searchCharacter(name)
            } else {
                Toast.makeText(this, "Введите имя", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun searchCharacter(name: String) {
        thread {
            try {
                val apiUrl = "https://rickandmortyapi.com/api/character/?name=${name.replace(" ", "+")}"
                val url = URL(apiUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000

                val responseCode = connection.responseCode
                println("Response Code: $responseCode") // Для отладки

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val inputStream = connection.inputStream
                    val response = inputStream.bufferedReader().use { it.readText() }
                    println("Response: $response") // Для отладки

                    val jsonResponse = JSONObject(response)
                    val results = jsonResponse.getJSONArray("results")

                    if (results.length() > 0) {
                        val character = results.getJSONObject(0)
                        runOnUiThread {
                            displayCharacterInfo(character)
                        }
                    } else {
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, "Персонаж не найден", Toast.LENGTH_SHORT).show()
                            textViewInfo.visibility = TextView.GONE
                            imageViewCharacter.visibility = ImageView.GONE
                        }
                    }
                } else {
                    runOnUiThread {
                        when (responseCode) {
                            404 -> Toast.makeText(this@MainActivity, "Персонаж '$name' не найден", Toast.LENGTH_SHORT).show()
                            else -> Toast.makeText(this@MainActivity, "Ошибка сервера: $responseCode", Toast.LENGTH_SHORT).show()
                        }
                        textViewInfo.visibility = TextView.GONE
                        imageViewCharacter.visibility = ImageView.GONE
                    }
                }
                connection.disconnect()
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Ошибка: ${e.message}", Toast.LENGTH_SHORT).show()
                    textViewInfo.visibility = TextView.GONE
                    imageViewCharacter.visibility = ImageView.GONE
                }
            }
        }
    }

    private fun displayCharacterInfo(character: JSONObject) {
        try {
            val name = character.getString("name")
            val status = character.getString("status")
            val species = character.getString("species")
            val type = if (character.getString("type").isNotEmpty()) character.getString("type") else "Не указан"
            val gender = character.getString("gender")
            val origin = character.getJSONObject("origin").getString("name")
            val location = character.getJSONObject("location").getString("name")
            val imageUrl = character.getString("image")

            val info = """
                Имя: $name
                Статус: $status
                Вид: $species
                Тип: $type
                Пол: $gender
                Происхождение: $origin
                Локация: $location
            """.trimIndent()

            runOnUiThread {
                textViewInfo.visibility = TextView.VISIBLE
                imageViewCharacter.visibility = ImageView.VISIBLE
                textViewInfo.text = info
            }

            loadImage(imageUrl)
        } catch (e: Exception) {
            runOnUiThread {
                Toast.makeText(this, "Ошибка обработки данных", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadImage(imageUrl: String) {
        thread {
            try {
                val url = URL(imageUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.doInput = true
                connection.connect()
                val inputStream = connection.inputStream
                val bitmap = BitmapFactory.decodeStream(inputStream)
                runOnUiThread {
                    imageViewCharacter.setImageBitmap(bitmap)
                }
                connection.disconnect()
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Ошибка загрузки изображения", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}