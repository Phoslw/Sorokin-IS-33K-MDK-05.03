package com.example.myapplication

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

fun <T> CoroutineScope.executeAsyncTask(
    onPreExecute: () -> Unit,
    doInBackground: () -> T,
    onPostExecute: (T) -> Unit
) = launch {
    onPreExecute()
    val result: T = withContext(Dispatchers.IO) {
        doInBackground()
    }
    onPostExecute(result)
}