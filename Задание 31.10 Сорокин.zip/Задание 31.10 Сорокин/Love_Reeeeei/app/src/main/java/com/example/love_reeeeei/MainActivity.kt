package com.example.love_reeeeei

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.bottom)
        val sun = findViewById<Spinner>(R.id.spinner)
        val sun1 = findViewById<Spinner>(R.id.spinner2)
        val text1 = findViewById<TextView>(R.id.textView4)
        val text2 = findViewById<EditText>(R.id.editTextText)

        val adapt = ArrayAdapter(this, android.R.layout.simple_spinner_item, arrayOf("RUB", "EUR", "USD", "CNY", "BYN"))
        adapt.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sun.adapter = adapt
        sun1.adapter = adapt

        button.setOnClickListener {
            try {
                val qaz = text2.text.toString().toDouble()
                val qwe1 = sun.selectedItem.toString()
                val qwe2 = sun1.selectedItem.toString()

                val monet = mapOf(
                    "RUB" to 1.0,
                    "USD" to 0.010309,
                    "EUR" to 0.009795,
                    "CNY" to 0.075328,
                    "BYN" to 0.033886
                )

                val red = monet[qwe1] ?: 1.0
                val red2 = monet[qwe2] ?: 1.0

                val result = (qaz * (red2 / red))
                val roundedResult = BigDecimal(result).setScale(2, RoundingMode.DOWN).toDouble()

                text1.text = roundedResult.toString()
            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Пожалуйста, введите число!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}