package com.example.yyy

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Инициализируем переменные для отображения текста и кнопки
        val tv = findViewById<TextView>(R.id.tv)
        val b = findViewById<Button>(R.id.button)

        val retrofit = Retrofit.Builder() //Создание экземпляра Retrofit
            .baseUrl("https://dummyjson.com/") //Базовый URL API
            .addConverterFactory(GsonConverterFactory.create()).build() //Конвертер JSON в объекты Kotlin
        val productAPI = retrofit.create(ProductAPI::class.java)

        b.setOnClickListener { //Обработчик нажатия кнопки
            CoroutineScope(Dispatchers.IO).launch { //Запуск корутины в фоновом потоке
                val product = productAPI.getProductById(1) //Получение продукта по ID
                runOnUiThread { //Установка текста в главном потоке
                    tv.text = product.title
                }
            }
        }
    }
}